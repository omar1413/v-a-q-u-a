<?php
      class S
      {
         public function ss()
          {
              echo "mahmoud";
          }
      }
?>