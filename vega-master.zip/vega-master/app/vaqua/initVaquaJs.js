/**
 * Created by Omar on 3/29/2017.
 */

// $("#upload").ready(function () {
//
//
//     $("#upload").change(function () {
//
//
//
//         var file_data = $('#upload').prop('files')[0];
//         var form_data = new FormData();
//         form_data.append('file', file_data);
//
//         $.ajax({
//             url: './app/vaqua/upload.php', // point to server-side PHP script
//             dataType: 'text',  // what to expect back from the PHP script, if anything
//             cache: false,
//             contentType: false,
//             processData: false,
//             data: form_data,
//             type: 'post',
//             success: function (php_script_response) {
//                 alert("done"); // display response from the PHP script, if any
//             }
//         });
//     });
//
// });





