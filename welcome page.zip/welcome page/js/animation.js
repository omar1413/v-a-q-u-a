// $(document).ready(function(){
//   $('.words1').slideDown(3000);
//   $('.img1').fadeIn(4000);
// }
// );
$(document).scroll(function() {
 var y = $(this).scrollTop();
 
 if(y>50)
 {
    $('.words1').slideDown(3000);
     $('.img1').fadeIn(4000);
 }


 if(y>350)
 {
     $('.upload').slideDown(2000);
     $('.question').slideDown(3000);
     $('.reply').slideDown(4000);
     $('.graph').slideDown(5000);
 }
 if(y>700)
 {
   $('.word3').slideDown(3000);
   $('.img3').fadeIn(2000);
 }
//    if(y>1500)
//  {
//     $('#serachConnecth').fadeIn(1200);
//  }
//  if(y>2000)
//  {
//       $('.createAccount').slideDown(2000);
//  }
//  if(y>2700)
//  {
//       $('.easyUpdate').slideDown(2000);
//  }
//
//  if(y>3100)
//  {
//      $('#simplePower').fadeIn(800);
//  }
//  if(y>3300)
//  {
//      $('.glyphicon-wrenchh').slideDown(700);
//      $('.glyphicon-timee').slideDown(1700);
//      $('.glyphicon-lockk').slideDown(2700);
//      $('.glyphicon-screenshott').slideDown(3700);
// }
// if(y>4400)
// {
//    $('.how1').slideDown(500);
//    $('.how2').slideDown(1500);
//    $('.how3').slideDown(2500);
// }
});
$('.section1words').click(function() {
    // rotation = 5;
   $('.sd').slideDown(2000);
});
