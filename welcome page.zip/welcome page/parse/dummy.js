file = [{
    "_id": "58bac23c26e76f544c1bce12",
    "index": 0,
    "guid": "90038332-5706-4b03-80a9-f771abee1996",
    "isActive": true,
    "balance": "$2,469.79",
    "picture": "http://placehold.it/32x32",
    "age": 34,
    "eyeColor": "blue"
}, {
    "_id": "58bac23c26e76f544c1bce12",
    "index": 0,
    "guid": "90038332-5706-4b03-80a9-f771abee1996",
    "isActive": true,
    "balance": "$2,469.79",
    "picture": "http://placehold.it/32x32",
    "age": 34,
    "eyeColor": "blue"
}, {
    "_id": "58bac23c26e76f544c1bce12",
    "index": 0,
    "guid": "90038332-5706-4b03-80a9-f771abee1996",
    "isActive": true,
    "balance": "$2,469.79",
    "picture": "http://placehold.it/32x32",
    "age": 34,
    "eyeColor": "blue"
}];
parse(file);

// params file passed
function parse(file) {
  for(var i=0;i<file.length;i++)
  {
    console.log('{');
    for (var prop in file[0]) {
        console.log(prop);
    }
    console.log('}');
  }
}
